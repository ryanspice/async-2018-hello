
				let data = [];
				for(var i = 0; i<125; i++){
					data.push({
						id:i,
						tag:Math.random(i*i)
					});
				}
				let index = 0;
				Element.prototype.appendAfter = function (element) {
				  element.parentNode.insertBefore(this, element.nextSibling);
				},false;
				Element.prototype.appendBefore = function (element) {
				  element.parentNode.insertBefore(this, element);
				},false;


				(function() {
				  var throttle = function(type, name, obj) {
				    obj = obj || window;
				    var running = false;
				    var func = function() {
				      if (running) { return; }
				      running = true;
				      requestAnimationFrame(function() {
				        obj.dispatchEvent(new CustomEvent(name));
				        running = false;
				      });
				    };
				    obj.addEventListener(type, func);
				  };

				  /* init - you can init any event */
				  throttle("resize", "optimizedResize");
				})();


let justScrolled = false;
let template =	new ATRender.pipe();



const _inital_height_ = height => Math.round((window.innerHeight/height) );

export default class VirtualScroll extends ATRender.view {

	constructor(){
		return super({
			type:`virtual-scroll`,
			id:``,
			style:``,
			innerHTML:`<template></template>`,
			mounted:async function(evt){

				let elm = this;
				let elementHeight = 115;
				let height = _inital_height_(elementHeight) + 150;

				//elm.style.maxHeight = window.innerHeight-300+"px";

				console.log(height)
				window.resize = this.resize;
				for (let i = 0; i<=Math.ceil(height*1.5); i++){

					template.a();
					template.defer = await [];
					template.template[0] = await [new VirtualItem(data[i])];
					await template.iterateTemplate();

				}

					var divs = document.getElementsByTagName("virtual-item");

					// handle event
					window.addEventListener("optimizedResize", async()=> {

						(elm.scrollTop=0);
											var divs = document.getElementsByTagName("virtual-item");
							let newHeight = Math.round((window.innerHeight/(elementHeight)/2) - 2);
							//elm.style.maxHeight = window.innerHeight-300+"px";

												if (index>=data.length-height+1) return;
												if (newHeight-height>data.length) return;
										return;
							for (let i = newHeight-height; i>0; i--){

								index--;
								if (data.length==divs.length) return;
								template.a();
								template.defer = await [];
								template.template[0] = await [new VirtualItem(i)];
								await template.iterateTemplate();

							}
							for (let i = await divs.length-1; i>0; i--){
							//console.log(data);

							divs[i].getElementsByTagName('h1')[0].innerText= await data[i].id;
							divs[i].getElementsByTagName('p')[0].innerText= await data[i].tag;

								}
								index=0;
					});


				elm.onscroll = async (event)=>{

					if (justScrolled){

						justScrolled=false;

						elm.scrollTop=Math.round(elm.scrollTop-100);

						return;
					}

					//Scrolling UP

					if (index>0)
					if(elm.children[1].getClientRects()[0].y>-115.88){
						index--;
						divs[divs.length-1].getElementsByTagName('h3')[0].innerText= data[index].id;
						divs[divs.length-1].getElementsByTagName('p')[0].innerText= data[index].tag;
						divs[divs.length-1].appendBefore(divs[0]);
						return;
					}

					if (index<data.length-height-2)
					if(elm.children[divs.length].getClientRects()[0].y+100<window.innerHeight-(elementHeight)){

						let b = elm.children[divs.length];
						divs[0].getElementsByTagName('h3')[0].innerText= data[index+height+2].id;
						divs[0].getElementsByTagName('p')[0].innerText= data[index+height+2].tag;
						divs[0].appendAfter(b);

						index++;
						//justScrolled = true;
						return;
					}

				}

			}
		});
	}

}
class VirtualItem extends ATRender.view {

	constructor(data){

		return super({
			type:`virtual-item`,
			style:``,
			renderTo:`virtual-scroll`,
			id:``,
			innerHTML:`<img width="105" height="105" style="float:left;" /> <h3>${data.id}</h3><p>${data.tag}</p>`
		});
	}

}
