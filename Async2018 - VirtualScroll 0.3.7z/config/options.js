export default {
	shell:{
		clear:false
		
	}
};
