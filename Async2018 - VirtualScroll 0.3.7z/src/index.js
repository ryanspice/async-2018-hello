
import './utils.js';

import {
	AsyncView,
	AsyncTemplate
} from "./entry";


const data = [];

let index = 0;
for(var i = 1; i<=125; i++){
	data.push({
		id:i,
		tag:Math.random(i*i),
		time:((new Date()).getTime())
	});
}

let justScrolled = false;
const template = new AsyncTemplate();
let divs;
let debug = true;

const elementHeight = 115.88;

const getHeight = () => {
	return Math.floor((window.innerHeight/elementHeight) * 1.2);
}

export {template, AsyncTemplate}

export default class VirtualScroll extends AsyncView {

	type:string = `virtual-scroll`;
	innerHTML:string = `<template></template>`;
	mounted = async function(evt){

		this.style.maxHeight = window.innerHeight-(elementHeight*2)+"px";

		const height = getHeight();

		//Push Items

		for (let i = 0; i<=height+6; i++){
			if(!data[i])
				continue;
			template.a();
			template.template[0] = await [await new VirtualItem(data[i])];
			await template.iterateTemplate();
		}

		divs = await this.getElementsByTagName("virtual-item");

		// VIRTUAL SCROLLING


		this.onscroll = async (event)=>{

			if (justScrolled){

				justScrolled=false;

				return;
			}

			//Scrolling

			if (
					(index>0)	&&
					(this.children[1].getClientRects()[0].y>-elementHeight)
				){

				index--;

				await VirtualItem.UpdateItem(divs[divs.length-1], data[index]);

				await divs[divs.length-1].appendBefore(divs[0]);

				//justScrolled = true;

				return;
			} else if (
					(index<data.length-height-2)	&&
					(this.children[divs.length].getClientRects()[0].y+elementHeight<window.innerHeight)
				){

				index++;

				await VirtualItem.UpdateItem(divs[0], data[index+height+1]);

				let b = this.children[divs.length];

				await divs[0].appendAfter(b);

				//justScrolled = true;

				return;
			}

		}

		// RESIZING

		const elm = this;
		window.addEventListener("optimizedResize", async()=> {

				let newHeight = Math.floor((window.innerHeight/elementHeight) * 1.2);
				elm.style.maxHeight = window.innerHeight-300+"px";

				return;
				for (let i = 0; i<newHeight-height; i++){

					await template.a();
					template.defer = await [];
					template.template[0] = await [
						await new VirtualItem(data[i+divs.length])
					];
					await index++;
					await template.iterateTemplate();

				}

				divs = await this.getElementsByTagName("virtual-item");
				index=0;

				return;
				for (let i = await divs.length-1; i>0; i--){
				console.log(data);

					//await VirtualItem.UpdateItem(divs[i], data[i]);
				}
		});


	}

}

class VirtualItem extends AsyncView {

	static UpdateItem = async function(item, data){

		item.getElementsByTagName('h3')[0].innerText= data.id;
		item.getElementsByTagName('p')[0].innerText= data.tag;

	}

	id:string = ``;
	//style:string = ``;
	type:string = `virtual-item`;
	renderTo:string = `virtual-scroll`;

	constructor(data){

		return super({
			innerHTML:`<svg class="feather feather-x sc-dnqmqq jxshSx" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-reactid="1376"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
			<img width="${elementHeight}" height="${elementHeight}" style="float:left;" src="./assets/150.png" srcs="https://picsum.photos/${elementHeight}/?random${data.time}"/> <h3>${data.id}</h3><p>${data.time}</p>`
		});
	}

}
